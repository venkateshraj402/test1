package com.example.demo.controller;

import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/post")
public class HomeController {

	@RequestMapping("/guest")
	@Secured("ROLE_USER")
	public String sayHelloToGuest() {
		return "Guest";
	}

	@Secured("ROLE_ADMIN")
	@RequestMapping("/user")
	public String sayHelloToUser() {
		return "User";
	}

	@Secured("ROLE_USER")
	@RequestMapping("/test")
	public String sayHelloToTest() {
		return "Test";
	}

}
