package com.hc.test;

import com.apollo.health.types.AdmissionInfo;
import com.apollo.health.types.BillSummary;
import com.apollo.health.types.TreatmentSummary;
import com.apollo.health.wsdl.Hospital;
import com.apollo.health.wsdl.HospitalFault;
import com.apollo.health.wsdl.HospitalImplService;

public class HCTest {
	public static void main(String[] args) {
		HospitalImplService service = new HospitalImplService();
		Hospital port = service.getHospitalImplPort();
		AdmissionInfo admissionInfo = new AdmissionInfo();
		admissionInfo.setAdmissionId("a1");
		admissionInfo.setPatientName("p1");
		admissionInfo.setRoomNo(1);
		
		TreatmentSummary ts = new TreatmentSummary();
		ts.setDisease("fewer");
		ts.setCost(2424.24f);
		
		try {
			BillSummary bs = port.generateBill(admissionInfo, ts);
			System.out.println("Status : " + bs.getStatus());
		} catch (HospitalFault e) {
			e.printStackTrace();
		}
		
	}
}
