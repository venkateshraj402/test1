package com.hc.dispatch;

import java.io.IOException;

import javax.xml.namespace.QName;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;

import javax.xml.ws.Dispatch;
import javax.xml.ws.Service;
import javax.xml.ws.soap.SOAPBinding;

public class HospitalDispatchTest {
	private final static String SERVICE_NM = "HosiptalSOAPService";
	private final static String PORT_NM = "HospitalSOAPPort";
	private final static String TARGET_NAMESPACE = "http://wsdl.health.apollo.com/";
	private final static String TYPE_NAMESPACE = "http://apollo.com/health/types";
	private final static String TARGET_ADDRESS = "http://localhost:8080/HospitalWeb/apollo";

	public static void main(String[] args) throws SOAPException, IOException {
		Service service = Service
				.create(new QName(TARGET_NAMESPACE, SERVICE_NM));
		service.addPort(new QName(TARGET_NAMESPACE, PORT_NM),
				SOAPBinding.SOAP11HTTP_BINDING, TARGET_ADDRESS);
		Dispatch<SOAPMessage> dispatch = service.createDispatch(new QName(
				TARGET_NAMESPACE, PORT_NM), SOAPMessage.class,
				Service.Mode.MESSAGE);
		MessageFactory mfactory = MessageFactory.newInstance();
		SOAPMessage request = mfactory.createMessage();
		SOAPPart part = request.getSOAPPart();
		SOAPBody body = part.getEnvelope().getBody();

		/* SOAPBody body = request.getSOAPBody(); */
		SOAPElement opNmElem = body.addChildElement("generateBill", "typ",
				TYPE_NAMESPACE);
		SOAPElement admissionPart = opNmElem.addChildElement("admissionInfo",
				"typ", TYPE_NAMESPACE);

		// admissionPart -- children
		SOAPElement admissionIdElem = admissionPart
				.addChildElement("admissionId");
		admissionIdElem.addTextNode("ad1");

		SOAPElement roomNoElem = admissionPart.addChildElement("roomNo");
		roomNoElem.addTextNode("1");

		SOAPElement patientNmElem = admissionPart
				.addChildElement("patientName");
		patientNmElem.addTextNode("p1");

		SOAPElement treatmentPart = opNmElem.addChildElement(
				"treatmentSummary", "typ", TYPE_NAMESPACE);
		SOAPElement diseaseElm = treatmentPart.addChildElement("disease");
		diseaseElm.addTextNode("fewer");

		SOAPElement costElm = treatmentPart.addChildElement("cost");
		costElm.addTextNode("131.23");

		request.writeTo(System.out);
		System.out.println("******response*******");
		SOAPMessage response = dispatch.invoke(request);
		response.writeTo(System.out);
	}
}
