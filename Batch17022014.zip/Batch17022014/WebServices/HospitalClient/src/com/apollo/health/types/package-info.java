@javax.xml.bind.annotation.XmlSchema(namespace = "http://apollo.com/health/types")
package com.apollo.health.types;
