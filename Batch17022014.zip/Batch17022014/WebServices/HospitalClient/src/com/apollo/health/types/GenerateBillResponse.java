
package com.apollo.health.types;

import javax.xml.bind.annotation.AccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.apollo.health.types.BillSummary;
import com.apollo.health.types.GenerateBillResponse;


/**
 * <p>Java class for generateBillResponse element declaration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;element name="generateBillResponse">
 *   &lt;complexType>
 *     &lt;complexContent>
 *       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *         &lt;sequence>
 *           &lt;element ref="{http://apollo.com/health/types}billSummary" minOccurs="0"/>
 *         &lt;/sequence>
 *       &lt;/restriction>
 *     &lt;/complexContent>
 *   &lt;/complexType>
 * &lt;/element>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(AccessType.FIELD)
@XmlType(name = "", propOrder = {
    "billSummary"
})
@XmlRootElement(name = "generateBillResponse")
public class GenerateBillResponse {

    @XmlElement(namespace = "http://apollo.com/health/types")
    protected BillSummary billSummary;

    /**
     * Gets the value of the billSummary property.
     * 
     * @return
     *     possible object is
     *     {@link BillSummary }
     *     
     */
    public BillSummary getBillSummary() {
        return billSummary;
    }

    /**
     * Sets the value of the billSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link BillSummary }
     *     
     */
    public void setBillSummary(BillSummary value) {
        this.billSummary = value;
    }

}
