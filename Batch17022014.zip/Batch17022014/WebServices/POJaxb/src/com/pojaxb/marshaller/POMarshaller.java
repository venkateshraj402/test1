package com.pojaxb.marshaller;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import com.amazon.sales.books.ItemType;
import com.amazon.sales.books.OrderItemsType;
import com.amazon.sales.books.PurchaseOrderType;
import com.amazon.sales.books.ShippingAddressType;

public class POMarshaller {
	public static void main(String[] args) throws JAXBException {
		ItemType itemType = new ItemType();
		itemType.setItemCode("ic1");
		itemType.setQuantity(2);

		ShippingAddressType sat = new ShippingAddressType();
		sat.setAddressLine1("addr1");
		sat.setAddressLine2("addr2");
		sat.setCity("hyderabad");
		sat.setState("ap");
		sat.setCountry("india");
		sat.setZip(242);
		sat.setType("permanent");

		OrderItemsType oit = new OrderItemsType();
		oit.getItem().add(itemType);

		PurchaseOrderType pot = new PurchaseOrderType();
		pot.setOrderItems(oit);
		pot.setShippingAddress(sat);

		JAXBContext jContext = JAXBContext
				.newInstance("com.amazon.sales.books");
		Marshaller marshaller = jContext.createMarshaller();		
		marshaller.marshal(pot, System.out);
	}
}
