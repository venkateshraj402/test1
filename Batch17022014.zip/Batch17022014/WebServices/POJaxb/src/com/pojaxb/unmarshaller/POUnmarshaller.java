package com.pojaxb.unmarshaller;

import java.io.File;

import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.xml.sax.SAXException;

import com.amazon.sales.books.PurchaseOrderType;

public class POUnmarshaller {
	private final static String XML_PATH = "C:\\Workshop\\Trainings\\WebServices\\Batch17022014\\WebServices\\POJaxb\\resources\\po.xml";
	private final static String XSD_PATH = "C:\\Workshop\\Trainings\\WebServices\\Batch17022014\\WebServices\\POJaxb\\resources\\po.xsd";

	public static void main(String[] args) throws JAXBException, SAXException {
		SchemaFactory sfactory = SchemaFactory
				.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
		Schema poSchema = sfactory.newSchema(new File(XSD_PATH));
		JAXBContext jContext = JAXBContext
				.newInstance("com.amazon.sales.books");
		Unmarshaller unmarshaller = jContext.createUnmarshaller();
		// enabling In-Memory validation
		unmarshaller.setSchema(poSchema);
		JAXBElement jElement = (JAXBElement) unmarshaller.unmarshal(new File(
				XML_PATH));
		PurchaseOrderType pot = (PurchaseOrderType) jElement.getValue();
		System.out.println("itemCode : "
				+ pot.getOrderItems().getItem().get(0).getItemCode());
		System.out.println("addressLine1 : "
				+ pot.getShippingAddress().getAddressLine1());
	}
}
