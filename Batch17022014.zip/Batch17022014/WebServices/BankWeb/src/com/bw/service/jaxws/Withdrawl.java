
package com.bw.service.jaxws;

import javax.xml.bind.annotation.AccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.bw.service.jaxws.Withdrawl;

@XmlRootElement(name = "withdrawl", namespace = "http://icicibank.com/trans/wsdl")
@XmlAccessorType(AccessType.FIELD)
@XmlType(name = "withdrawl", namespace = "http://icicibank.com/trans/wsdl", propOrder = {
    "accountInfo",
    "transactionInfo"
})
public class Withdrawl {

    @XmlElement(name = "accountInfo", namespace = "http://icicibank.com/types")
    private com.bw.dto.AccountInfo accountInfo;
    @XmlElement(name = "transactionInfo", namespace = "http://icicibank.com/types")
    private com.bw.dto.TransactionInfo transactionInfo;

    /**
     * 
     * @return
     *     returns AccountInfo
     */
    public com.bw.dto.AccountInfo getAccountInfo() {
        return this.accountInfo;
    }

    /**
     * 
     * @param accountInfo
     *     the value for the accountInfo property
     */
    public void setAccountInfo(com.bw.dto.AccountInfo accountInfo) {
        this.accountInfo = accountInfo;
    }

    /**
     * 
     * @return
     *     returns TransactionInfo
     */
    public com.bw.dto.TransactionInfo getTransactionInfo() {
        return this.transactionInfo;
    }

    /**
     * 
     * @param transactionInfo
     *     the value for the transactionInfo property
     */
    public void setTransactionInfo(com.bw.dto.TransactionInfo transactionInfo) {
        this.transactionInfo = transactionInfo;
    }

}
