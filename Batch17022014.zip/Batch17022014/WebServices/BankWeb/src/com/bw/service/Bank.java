package com.bw.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;

import com.bw.dto.AccountInfo;
import com.bw.dto.Receipt;
import com.bw.dto.TransactionInfo;

@WebService(targetNamespace = "http://icicibank.com/trans/wsdl", name = "Bank")
public interface Bank {
	
	@WebMethod(action = "http://icicibank.com/trans/wsdl#withdrawl")
	@WebResult(name = "receipt", targetNamespace = "http://icicibank.com/types")	
	Receipt withdrawl(
			@WebParam(name = "accountInfo", targetNamespace = "http://icicibank.com/types") AccountInfo accountInfo,
			@WebParam(name = "transactionInfo", targetNamespace = "http://icicibank.com/types") TransactionInfo transactionInfo);
}
