package com.bw.service;

import javax.jws.WebService;

import com.bw.dto.AccountInfo;
import com.bw.dto.Receipt;
import com.bw.dto.TransactionInfo;

@WebService(endpointInterface = "com.bw.service.Bank", serviceName = "BankService", portName = "BankSOAPPort")
public class BankImpl {

	public Receipt withdrawl(AccountInfo accountInfo,
			TransactionInfo transactionInfo) {
		Receipt receipt = null;

		receipt = new Receipt();
		receipt.setTransactionId(121);
		receipt.setBalance(transactionInfo.getAmount());
		receipt.setStatusCode("SUCCESS");

		return receipt;
	}

}
