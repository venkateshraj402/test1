
package com.bw.service.jaxws;

import javax.xml.bind.annotation.AccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.bw.service.jaxws.WithdrawlResponse;

@XmlRootElement(name = "withdrawlResponse", namespace = "http://icicibank.com/trans/wsdl")
@XmlAccessorType(AccessType.FIELD)
@XmlType(name = "withdrawlResponse", namespace = "http://icicibank.com/trans/wsdl")
public class WithdrawlResponse {

    @XmlElement(name = "receipt", namespace = "http://icicibank.com/types")
    private com.bw.dto.Receipt _return;

    /**
     * 
     * @return
     *     returns Receipt
     */
    public com.bw.dto.Receipt get_return() {
        return this._return;
    }

    /**
     * 
     * @param _return
     *     the value for the _return property
     */
    public void set_return(com.bw.dto.Receipt _return) {
        this._return = _return;
    }

}
