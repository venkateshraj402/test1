package com.po.test;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import com.po.handler.TotalQuantityHandler;
import com.po.parser.TotalQuantityParser;

public class TotalQuantityTest {
	public static void main(String[] args) throws ParserConfigurationException,
			SAXException, IOException {
		TotalQuantityParser parser = new TotalQuantityParser();
		TotalQuantityHandler handler = new TotalQuantityHandler();

		parser.findTotal(
				"C:\\Workshop\\Trainings\\WebServices\\Batch17022014\\WebServices\\POSax\\resource\\po.xml",
				handler);
	}
}
