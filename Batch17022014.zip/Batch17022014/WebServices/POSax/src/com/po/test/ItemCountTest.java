package com.po.test;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import com.po.handler.ItemCountHandler;
import com.po.parser.ItemCountParser;

public class ItemCountTest {

	public static void main(String[] args) throws ParserConfigurationException,
			SAXException, IOException {
		ItemCountParser parser = new ItemCountParser();
		ItemCountHandler handler = new ItemCountHandler();
		parser.countItems(
				"C:\\Workshop\\Trainings\\WebServices\\Batch17022014\\WebServices\\POSax\\resource\\po.xml",
				handler);

		parser.countItems(
				"C:\\Workshop\\Trainings\\WebServices\\Batch17022014\\WebServices\\POSax\\resource\\po1.xml",
				handler);

	}
}
