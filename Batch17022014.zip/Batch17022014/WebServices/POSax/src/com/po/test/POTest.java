package com.po.test;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import com.po.parser.ViewPOParser;

public class POTest {
	private final static String FILE_PATH = "C:\\Workshop\\Trainings\\WebServices\\Batch17022014\\WebServices\\POSax\\resource\\po.xml";

	public static void main(String[] args) throws ParserConfigurationException,
			SAXException, IOException {
		ViewPOParser poParser = new ViewPOParser();
		poParser.print(FILE_PATH);
	}
}
