package com.po.handler;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class ViewPOHandler extends DefaultHandler {

	@Override
	public void characters(char[] doc, int offSet, int len) throws SAXException {
		String data = new String(doc, offSet, len);
		System.out.print(data);
	}

	@Override
	public void endDocument() throws SAXException {
		System.out.println("END DOCUMENT");
	}

	@Override
	public void endElement(String namespaceUri, String localName, String qName)
			throws SAXException {
		System.out.println("</" + localName + ">");
	}

	@Override
	public void startDocument() throws SAXException {
		System.out.println("START DOCUMENT");
	}

	@Override
	public void startElement(String namespaceUri, String localName,
			String qName, Attributes attributes) throws SAXException {
		System.out.print("<" + localName + ">");
	}

}
