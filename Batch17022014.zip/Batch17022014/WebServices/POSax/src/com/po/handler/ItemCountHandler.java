package com.po.handler;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class ItemCountHandler extends DefaultHandler {
	private int count;

	@Override
	public void startDocument() throws SAXException {
		count = 0;
	}

	@Override
	public void startElement(String namespaceUri, String localName,
			String qName, Attributes attributes) throws SAXException {
		if (qName.equals("item")) {
			count++;
		}
	}

	public int getCount() {
		return count;
	}

}
