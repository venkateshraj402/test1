package com.po.handler;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class TotalQuantityHandler extends DefaultHandler {
	private int total;
	private String lastProcessedElement;

	@Override
	public void characters(char[] doc, int offSet, int len) throws SAXException {
		String data = null;

		data = new String(doc, offSet, len);
		if (lastProcessedElement != null
				&& lastProcessedElement.equals("quantity")) {
			total += Integer.parseInt(data);
			lastProcessedElement = null;
		}
	}

	@Override
	public void startDocument() throws SAXException {
		total = 0;
		lastProcessedElement = null;
	}

	@Override
	public void startElement(String namespaceUri, String localName,
			String qName, Attributes attributes) throws SAXException {
		lastProcessedElement = qName;
	}

	public int getTotal() {
		return total;
	}

}
