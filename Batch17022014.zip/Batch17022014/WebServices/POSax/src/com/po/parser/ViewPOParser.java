package com.po.parser;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.SAXException;

import com.po.handler.ViewPOHandler;

public class ViewPOParser {
	public void print(final String path) throws ParserConfigurationException,
			SAXException, IOException {
		SAXParserFactory sfactory = SAXParserFactory.newInstance();
		sfactory.setNamespaceAware(true);
		SAXParser parser = sfactory.newSAXParser();
		parser.parse(new File(path), new ViewPOHandler());
	}
}
