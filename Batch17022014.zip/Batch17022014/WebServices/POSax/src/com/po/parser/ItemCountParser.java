package com.po.parser;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.SAXException;

import com.po.handler.ItemCountHandler;

public class ItemCountParser {
	public void countItems(String path, ItemCountHandler handler)
			throws ParserConfigurationException, SAXException, IOException {
		SAXParserFactory sfactory = SAXParserFactory.newInstance();
		SAXParser parser = sfactory.newSAXParser();
		parser.parse(new File(path), handler);
		System.out.println("No of items : " + handler.getCount());
	}
}
