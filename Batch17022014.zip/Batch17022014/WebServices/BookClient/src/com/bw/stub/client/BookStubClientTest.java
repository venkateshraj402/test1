package com.bw.stub.client;

import java.rmi.RemoteException;

import javax.xml.rpc.ServiceException;

import com.bw.service.BookInfo;
import com.bw.service.BookInfoService;
import com.bw.service.BookInfoService_Impl;

public class BookStubClientTest {
	public static void main(String[] args) throws ServiceException,
			RemoteException {
		BookInfoService service = new BookInfoService_Impl();
		BookInfo port = service.getBookInfoPort();
		float price = port.getBookPrice("ISBN1001");
		System.out.println("price : " + price);
	}
}
