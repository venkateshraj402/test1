package com.bw.dii.client;

import java.rmi.RemoteException;

import javax.xml.namespace.QName;
import javax.xml.rpc.Call;
import javax.xml.rpc.ParameterMode;
import javax.xml.rpc.Service;
import javax.xml.rpc.ServiceException;
import javax.xml.rpc.ServiceFactory;

public class BookInfoDIITest {
	private static final String ENDPOINT_URL = "http://localhost:8080/BookWeb/bookEquiry";
	private static final String TRGT_NMSPC = "http://amazon.org/sales/books/wsdl";
	private static final String TYP_NMSPC = "http://www.w3.org/2001/XMLSchema";
	private static final String SERVICE_NM = "BookInfoService";
	private static final String PORT_NM = "BookInfoPort";
	private static final String OPERATION_NM = "getBookPrice";
	private static final String ENCODING_STYLE_URI = "http://schemas.xmlsoap.org/soap/encoding/";

	public static void main(String[] args) throws ServiceException,
			RemoteException {
		ServiceFactory sfactory = ServiceFactory.newInstance();
		Service bookInfoService = sfactory.createService(new QName(TRGT_NMSPC,
				SERVICE_NM));

		// create call representing method of provider
		Call call_getBookPrice = bookInfoService.createCall(new QName(
				TRGT_NMSPC, PORT_NM));
		// point to specific method of the port
		call_getBookPrice.setOperationName(new QName(TRGT_NMSPC, OPERATION_NM));

		// attach physical address of the endpoint
		call_getBookPrice.setTargetEndpointAddress(ENDPOINT_URL);

		// as there is no stub/sei impl
		/**
		 * All the details about the method their parameters and return types
		 * has to be declared
		 */
		call_getBookPrice.addParameter("String_1", new QName(TYP_NMSPC,
				"string"), ParameterMode.IN);
		call_getBookPrice.setReturnType(new QName(TYP_NMSPC, "float"));

		call_getBookPrice.setProperty(Call.SOAPACTION_USE_PROPERTY, true);
		call_getBookPrice.setProperty(Call.SOAPACTION_URI_PROPERTY, "");
		call_getBookPrice.setProperty(Call.ENCODINGSTYLE_URI_PROPERTY,
				ENCODING_STYLE_URI);

		Float price = (Float) call_getBookPrice
				.invoke(new Object[] { "ISBN1001" });
		System.out.println("Price : " + price);
	}
}
