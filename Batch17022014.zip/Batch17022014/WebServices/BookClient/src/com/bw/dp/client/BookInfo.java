package com.bw.dp.client;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface BookInfo extends Remote {
	float getBookPrice(String String_1) throws RemoteException;
}
