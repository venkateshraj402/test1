package com.bw.dp.client;

import java.net.MalformedURLException;
import java.rmi.RemoteException;

import javax.xml.namespace.QName;
import javax.xml.rpc.Service;
import javax.xml.rpc.ServiceException;
import javax.xml.rpc.ServiceFactory;

public class DPClientTest {
	private static final String WSDL_URL = "http://localhost:8080/BookWeb/bookEquiry?WSDL";
	private static final String TARGET_NAMESPACE = "http://amazon.org/sales/books/wsdl";
	private static final String SERVICE_NM = "BookInfoService";
	private static final String PORT_NM = "BookInfoPort";

	public static void main(String[] args) throws ServiceException,
			MalformedURLException, RemoteException {
		ServiceFactory sfactory = ServiceFactory.newInstance();
		Service bookInfoService = sfactory.createService(new java.net.URL(
				WSDL_URL), new QName(TARGET_NAMESPACE, SERVICE_NM));
		BookInfo port = (BookInfo) bookInfoService.getPort(new QName(
				TARGET_NAMESPACE, PORT_NM), BookInfo.class);
		float price = port.getBookPrice("ISBN1001");
		System.out.println("price : " + price);
	}
}
