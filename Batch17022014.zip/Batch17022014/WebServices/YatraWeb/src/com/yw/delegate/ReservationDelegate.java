package com.yw.delegate;

import java.rmi.RemoteException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.xml.rpc.ServiceException;

import in.co.irctc.reservation.types.JourneyInfo;
import in.co.irctc.reservation.types.PassengerInfo;
import in.co.irctc.reservation.types.Ticket;
import in.co.irctc.reservation.wsdl.TrainInfo;

import com.yw.util.TrainInfoLocator;
import com.yw.valueobjects.ReservationVO;
import com.yw.valueobjects.TicketDetailVO;

public class ReservationDelegate {
	public TicketDetailVO reserve(ReservationVO vo) {
		TrainInfo port = null;
		PassengerInfo pInfo = null;
		JourneyInfo jInfo = null;
		Ticket ticket = null;
		SimpleDateFormat sdf = null;
		TicketDetailVO ticketDetailVO = null;
		TrainInfoLocator trainInfoLocator = null;

		try {
			sdf = new SimpleDateFormat("dd/mm/yyyy");
			pInfo = new PassengerInfo();
			pInfo.setSsn(vo.getSsn());
			pInfo.setGender(vo.getGender());
			pInfo.setDob(sdf.parse(vo.getDob()));

			jInfo = new JourneyInfo();
			jInfo.setSrc(vo.getSrc());
			jInfo.setDest(vo.getDest());
			jInfo.setDoj(sdf.parse(vo.getDoj()));

			trainInfoLocator = new TrainInfoLocator();
			port = trainInfoLocator.getTrainInfoPort();

			ticket = port.bookTicket(pInfo, jInfo);
			ticketDetailVO = new TicketDetailVO();
			ticketDetailVO.setPnr(ticket.getPnr());
			ticketDetailVO.setBerth(ticket.getBerth().toString());
			ticketDetailVO.setCoach(ticket.getCoach());
			ticketDetailVO.setStatus(ticket.getStatus());

		} catch (ParseException e) {
			e.printStackTrace();
		} catch (ServiceException e) {
			e.printStackTrace();
		} catch (RemoteException e) {
			e.printStackTrace();
		}

		return ticketDetailVO;
	}
}
