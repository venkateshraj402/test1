package com.yw.util;

import javax.xml.rpc.ServiceException;

import in.co.irctc.reservation.wsdl.TrainInfo;
import in.co.irctc.reservation.wsdl.TrainInfoService;
import in.co.irctc.reservation.wsdl.TrainInfoServiceLocator;

/**
 * Service Locator (gives the port of TrainInfoService)
 */
public class TrainInfoLocator {
	/**
	 * Service Locator method to get the port object
	 * 
	 * @return
	 * @throws ServiceException
	 */
	public TrainInfo getTrainInfoPort() throws ServiceException {
		TrainInfo port = null;
		TrainInfoService service = null;

		service = new TrainInfoServiceLocator();
		port = service.getTrainInfoSOAPPort();
		return port;
	}
}
