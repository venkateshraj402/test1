package com.podom.parser;

import java.io.File;
import java.io.IOException;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;

public class PODomParser {
	public void printNode(final String path)
			throws ParserConfigurationException, SAXException, IOException {
		SchemaFactory sfactory = SchemaFactory
				.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
		Schema poSchema = sfactory
				.newSchema(new File(
						"C:\\Workshop\\Trainings\\WebServices\\Batch17022014\\WebServices\\PODom\\resource\\po.xsd"));
		Validator validator = poSchema.newValidator();
		//validator.validate(new StreamSource(new File(path)));

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document doc = builder.parse(new File(path));

		System.out.println(doc.getFirstChild().getFirstChild().getNodeName());
	}

}
