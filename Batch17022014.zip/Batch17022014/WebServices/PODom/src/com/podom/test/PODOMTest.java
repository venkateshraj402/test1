package com.podom.test;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import com.podom.parser.PODomParser;

public class PODOMTest {
	public static void main(String[] args) throws ParserConfigurationException,
			SAXException, IOException {
		PODomParser poParser = new PODomParser();
		poParser.printNode("C:\\Workshop\\Trainings\\WebServices\\Batch17022014\\WebServices\\PODom\\resource\\po.xml");
	}
}
