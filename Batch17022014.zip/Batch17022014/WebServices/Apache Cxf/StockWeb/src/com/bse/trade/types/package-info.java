@javax.xml.bind.annotation.XmlSchema(namespace = "http://bse.com/trade/types")
package com.bse.trade.types;
