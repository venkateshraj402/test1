package com.bw.service;

import java.rmi.RemoteException;

public class BookInfoImpl implements BookInfo {
	public float getBookPrice(String isbn) throws RemoteException {
		float price = 0.0f;

		if (isbn == null || isbn.equals("")) {
			throw new RemoteException("Invalid isbn");
		}

		if (isbn.equals("ISBN1001")) {
			price = 100.234f;
		} else if (isbn.equals("ISBN1002")) {
			price = 200.34f;
		} else {
			price = 500.00f;
		}

		return price;
	}
}
