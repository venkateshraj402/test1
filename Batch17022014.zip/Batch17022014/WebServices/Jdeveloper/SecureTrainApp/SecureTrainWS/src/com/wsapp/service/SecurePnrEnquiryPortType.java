package com.wsapp.service;

import java.rmi.Remote;

import javax.jws.WebService;

@WebService
public interface SecurePnrEnquiryPortType extends Remote {
    public String getPnrStatus(String pnr);
}
