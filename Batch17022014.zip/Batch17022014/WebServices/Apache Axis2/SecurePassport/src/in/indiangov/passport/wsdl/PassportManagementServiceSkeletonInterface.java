
/**
 * PassportManagementServiceSkeletonInterface.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.1  Built on : Aug 31, 2011 (12:22:40 CEST)
 */
    package in.indiangov.passport.wsdl;
    /**
     *  PassportManagementServiceSkeletonInterface java skeleton interface for the axisService
     */
    public interface PassportManagementServiceSkeletonInterface {
     
         
        /**
         * Auto generated method signature
         * 
                                    * @param personInfo
         */

        
                public in.indiangov.passport.types.Receipt apply
                (
                  in.indiangov.passport.types.PersonInfo personInfo
                 )
            ;
        
         }
    