package com.insurance.service;

public class InsuranceImpl implements Insurance {

	public MembershipCard enroll(MemberInfo mInfo, PolicyInfo pInfo) {
		// bussiness logic
		MembershipCard card = null;

		card = new MembershipCard();
		card.setEnrollmentNo(mInfo.getSsn() + "E");
		card.setStatus("Active");
		return card;
	}

}
