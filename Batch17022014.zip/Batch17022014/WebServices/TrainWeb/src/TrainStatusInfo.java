public class TrainStatusInfo {

	public String getPnrStatus(String pnr) {
		return "pnr : " + pnr + " status : WL/4";
	}
}
