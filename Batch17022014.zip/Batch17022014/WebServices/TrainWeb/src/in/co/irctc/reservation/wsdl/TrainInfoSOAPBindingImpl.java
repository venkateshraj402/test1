/**
 * TrainInfoSOAPBindingImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package in.co.irctc.reservation.wsdl;

import in.co.irctc.reservation.types.Ticket;

public class TrainInfoSOAPBindingImpl implements
		in.co.irctc.reservation.wsdl.TrainInfo {
	public in.co.irctc.reservation.types.Ticket bookTicket(
			in.co.irctc.reservation.types.PassengerInfo pInfo,
			in.co.irctc.reservation.types.JourneyInfo jInfo)
			throws java.rmi.RemoteException {
		Ticket ticket = null;

		ticket = new Ticket();
		ticket.setPnr(pInfo.getSsn() + "pnr");
		ticket.setBerth(12);
		ticket.setCoach("S1");
		ticket.setStatus("Confirmed");
		return ticket;
	}

}
