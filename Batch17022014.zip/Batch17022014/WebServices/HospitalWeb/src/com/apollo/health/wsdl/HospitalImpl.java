package com.apollo.health.wsdl;

import javax.jws.WebService;

import com.apollo.health.types.AdmissionInfo;
import com.apollo.health.types.BillSummary;
import com.apollo.health.types.HospitalFault;
import com.apollo.health.types.TreatmentSummary;

@WebService(endpointInterface = "com.apollo.health.wsdl.Hospital", serviceName = "HosiptalSOAPService", portName = "HospitalSOAPPort")
public class HospitalImpl {

	public BillSummary generateBill(AdmissionInfo admissionInfo,
			TreatmentSummary treatmentSummary) throws BillGenerationFault {
		BillSummary billSummary = null;

		if (admissionInfo.getPatientName() == null
				|| admissionInfo.getPatientName().equals("")) {
			HospitalFault hf = new HospitalFault();
			hf.setHospitalFaultCode("Input:Invalid");
			hf.setMessage("Required inputs are missing");

			throw new BillGenerationFault("PatientName is mandatory", hf);
		}
		billSummary = new BillSummary();
		billSummary.setAdmissionId(admissionInfo.getAdmissionId());
		billSummary.setAmount(414112.24f);
		billSummary.setBillno(242.234f);
		billSummary.setStatus("ALive");
		return billSummary;
	}

}
