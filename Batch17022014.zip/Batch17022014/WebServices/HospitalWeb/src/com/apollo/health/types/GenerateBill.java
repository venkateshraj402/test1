
package com.apollo.health.types;

import javax.xml.bind.annotation.AccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.apollo.health.types.AdmissionInfo;
import com.apollo.health.types.GenerateBill;
import com.apollo.health.types.TreatmentSummary;


/**
 * <p>Java class for generateBill element declaration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;element name="generateBill">
 *   &lt;complexType>
 *     &lt;complexContent>
 *       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *         &lt;sequence>
 *           &lt;element ref="{http://apollo.com/health/types}admissionInfo"/>
 *           &lt;element ref="{http://apollo.com/health/types}treatmentSummary"/>
 *         &lt;/sequence>
 *       &lt;/restriction>
 *     &lt;/complexContent>
 *   &lt;/complexType>
 * &lt;/element>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(AccessType.FIELD)
@XmlType(name = "", propOrder = {
    "admissionInfo",
    "treatmentSummary"
})
@XmlRootElement(name = "generateBill")
public class GenerateBill {

    @XmlElement(namespace = "http://apollo.com/health/types")
    protected AdmissionInfo admissionInfo;
    @XmlElement(namespace = "http://apollo.com/health/types")
    protected TreatmentSummary treatmentSummary;

    /**
     * Gets the value of the admissionInfo property.
     * 
     * @return
     *     possible object is
     *     {@link AdmissionInfo }
     *     
     */
    public AdmissionInfo getAdmissionInfo() {
        return admissionInfo;
    }

    /**
     * Sets the value of the admissionInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link AdmissionInfo }
     *     
     */
    public void setAdmissionInfo(AdmissionInfo value) {
        this.admissionInfo = value;
    }

    /**
     * Gets the value of the treatmentSummary property.
     * 
     * @return
     *     possible object is
     *     {@link TreatmentSummary }
     *     
     */
    public TreatmentSummary getTreatmentSummary() {
        return treatmentSummary;
    }

    /**
     * Sets the value of the treatmentSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link TreatmentSummary }
     *     
     */
    public void setTreatmentSummary(TreatmentSummary value) {
        this.treatmentSummary = value;
    }

}
