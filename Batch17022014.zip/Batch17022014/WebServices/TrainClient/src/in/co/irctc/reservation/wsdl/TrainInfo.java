/**
 * TrainInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package in.co.irctc.reservation.wsdl;

public interface TrainInfo extends java.rmi.Remote {
    public in.co.irctc.reservation.types.Ticket bookTicket(in.co.irctc.reservation.types.PassengerInfo pInfo, in.co.irctc.reservation.types.JourneyInfo jInfo) throws java.rmi.RemoteException;
}
