package com.hm.resource;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.URI;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.StreamingOutput;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.hm.domain.Order;

@Path("/order")
public class OrderResource {
	private Map<Integer, Order> orderMap;
	private AtomicInteger counter;

	public OrderResource() {
		orderMap = new ConcurrentHashMap<Integer, Order>();
		counter = new AtomicInteger(0);
	}

	@POST
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.TEXT_PLAIN)
	public Response createOrder(InputStream in) {
		Order order = null;

		try {
			order = buildOrder(in);
			order.setId(counter.incrementAndGet());
			orderMap.put(order.getId(), order);
		} catch (Exception e) {
			return Response.serverError().build();
		}
		return Response.created(URI.create("/order?id=" + order.getId()))
				.build();
	}

	@PUT
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.TEXT_PLAIN)
	public Response updateOrder(InputStream in) {
		Order order = null;

		try {
			order = buildOrder(in);
			// update if existing
			if (orderMap.containsKey(order.getId())) {
				orderMap.put(order.getId(), order);
			} else {
				return Response.notModified().build();
			}
		} catch (Exception e) {
			return Response.serverError().build();
		}
		return Response.ok(
				"Order Id : " + order.getId() + " updated successfully")
				.build();
	}

	@GET
	@Produces(MediaType.APPLICATION_XML)
	public StreamingOutput getOrder(@QueryParam("id") int id) {
		Order order = null;
		String orderXml = null;

		if (orderMap.containsKey(id)) {
			order = orderMap.get(id);
			orderXml = generateOrder(order);
			return new OrderStreamingOuput(orderXml);
		}
		return null;
	}

	private final class OrderStreamingOuput implements StreamingOutput {
		private String xml;

		public OrderStreamingOuput(String xml) {
			this.xml = xml;
		}

		@Override
		public void write(OutputStream out) throws IOException,
				WebApplicationException {
			PrintWriter pw = new PrintWriter(out);
			pw.print(xml);
			pw.close();
		}
	}

	private Order buildOrder(InputStream in)
			throws ParserConfigurationException, SAXException, IOException {
		DocumentBuilderFactory factory = null;
		DocumentBuilder builder = null;
		Document doc = null;
		Order order = null;
		Node root = null;
		NodeList children = null;

		factory = DocumentBuilderFactory.newInstance();
		builder = factory.newDocumentBuilder();
		doc = builder.parse(in);

		if (doc != null) {
			order = new Order();
			root = doc.getFirstChild();
			children = root.getChildNodes();
			for (int i = 0; i < children.getLength(); i++) {
				Node child = children.item(i);
				if (child.getNodeName().equals("id")) {
					order.setId(Integer.parseInt(child.getTextContent()));
				} else if (child.getNodeName().equals("type")) {
					order.setType(child.getTextContent());
				} else if (child.getNodeName().equals("price")) {
					order.setPrice(Float.parseFloat(child.getTextContent()));
				}
			}
		}

		return order;
	}

	private String generateOrder(Order order) {
		StringBuffer buffer = null;

		buffer = new StringBuffer();
		if (order != null) {
			buffer.append("<order>");
			buffer.append("<id>").append(order.getId()).append("</id>");
			buffer.append("<type>").append(order.getType()).append("</type>");
			buffer.append("<price>").append(order.getPrice())
					.append("</price>");
			buffer.append("</order>");
		}
		return buffer.toString();
	}

}
