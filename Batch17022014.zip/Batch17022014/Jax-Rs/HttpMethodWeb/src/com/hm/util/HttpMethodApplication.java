package com.hm.util;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import com.hm.resource.OrderResource;

@ApplicationPath("/rest")
public class HttpMethodApplication extends Application {
	private Set<Object> singletons;

	public HttpMethodApplication() {
		singletons = new HashSet<Object>();
		singletons.add(new OrderResource());
	}

	@Override
	public Set<Object> getSingletons() {
		return singletons;
	}

}
