package com.cw.resource;

import java.util.Calendar;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.CacheControl;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.EntityTag;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import com.cw.domain.Customer;

@Path("/customer")
public class CustomerResource {
	private Map<Integer, Customer> dbMap;

	public CustomerResource() {
		dbMap = new ConcurrentHashMap<Integer, Customer>();
	}

	@GET
	@Path("/name/{id}")
	public Response getCustomerName(@PathParam("id") int id) {
		Calendar cal = null;

		System.out.println("getCustomerName()");
		cal = Calendar.getInstance();
		cal.set(Calendar.YEAR, 2014);
		cal.set(Calendar.MONTH, 6);
		cal.set(Calendar.DAY_OF_MONTH, 15);
		cal.set(Calendar.HOUR, 6);
		cal.set(Calendar.MINUTE, 17);
		cal.set(Calendar.SECOND, 0);

		return Response.ok().entity("N.T Rama rao").expires(cal.getTime())
				.build();
	}

	@Path("/firstname/{id}")
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public Response getFirstName(@PathParam("id") int id) {
		CacheControl cc = null;

		cc = new CacheControl();
		cc.setMaxAge(10000);
		cc.setPrivate(true);
		System.out.println("getFirstName()");

		return Response.ok().entity("Rama rao").cacheControl(cc).build();
	}

	@POST
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/saveOrUpdate")
	public Response saveOrUpdateCustomer(Customer customer,
			@Context Request request) {
		ResponseBuilder builder = null;
		Customer dbcustomer = null;
		EntityTag eTag = null;

		// customer from db
		if (dbMap.containsKey(customer.getId())) {
			dbcustomer = dbMap.get(customer.getId());
			eTag = new EntityTag(String.valueOf(dbcustomer.hashCode()));
			builder = request.evaluatePreconditions(
					dbcustomer.getLastModifiedDate(), eTag);
			if (builder == null) {
				dbMap.put(customer.getId(), customer);
				return Response.ok(
						"Customer : " + customer.getId()
								+ " saved or updated successfully!").build();
			}
			return builder.build();
		} else {
			// insert case
			dbMap.put(customer.getId(), customer);
			return Response.ok(
					"Customer : " + customer.getId()
							+ " saved or updated successfully!").build();
		}

	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/detail/{id}")
	public Response getCustomer(@PathParam("id") Integer id,
			@Context Request request) {
		ResponseBuilder builder = null;
		CacheControl cc = null;
		EntityTag eTag = null;
		Customer customer = null;

		cc = new CacheControl();
		cc.setMaxAge(90000);
		cc.setMustRevalidate(true);
		cc.setNoCache(true);

		customer = dbMap.get(id);
		eTag = new EntityTag(String.valueOf(customer.hashCode()));
		builder = request.evaluatePreconditions(eTag);
		// data found in cache send redirect request
		if (builder != null) {
			System.out.println("from cache...");
			return builder.cacheControl(cc).build();
		}

		System.out.println("from server...");
		return Response.ok().entity(dbMap.get(id)).cacheControl(cc).tag(eTag)
				.build();
	}
}
