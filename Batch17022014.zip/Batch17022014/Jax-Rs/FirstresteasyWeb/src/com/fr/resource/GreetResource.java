package com.fr.resource;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Path("/greet")
public class GreetResource {

	public GreetResource() {
		System.out.println("Greet resource created...");
	}

	@Produces(MediaType.TEXT_PLAIN)
	@GET
	public String greet(@QueryParam("name") String person) {
		return "Hello " + person + " !";
	}
}
