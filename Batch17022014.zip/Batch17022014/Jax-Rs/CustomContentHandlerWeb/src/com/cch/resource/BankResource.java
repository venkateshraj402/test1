package com.cch.resource;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.cch.domain.AccountInfo;
import com.cch.domain.PersonalInfo;

@Path("/bank")
public class BankResource {

	@POST
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_XML)
	@Path("/newAccount")
	public AccountInfo openAccount(PersonalInfo personalInfo) {
		AccountInfo accountInfo = null;

		accountInfo = new AccountInfo();
		accountInfo.setAccNo("Ac11");
		accountInfo.setName(personalInfo.getName());
		return accountInfo;
	}

}
