package com.cch.handler;

import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.ext.ContextResolver;
import javax.ws.rs.ext.Provider;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;

import com.cch.domain.AccountInfo;
import com.cch.domain.PersonalInfo;

@Provider
@Produces(MediaType.APPLICATION_XML)
public class JAXBContextResolver implements ContextResolver<JAXBContext> {
	private JAXBContext jContext;

	public JAXBContextResolver() {
		try {
			jContext = JAXBContext.newInstance(AccountInfo.class,
					PersonalInfo.class);
		} catch (JAXBException e) {
			e.printStackTrace();
		}
	}

	@Override
	public JAXBContext getContext(Class<?> classType) {
		if (classType.isAssignableFrom(PersonalInfo.class)
				|| classType.isAssignableFrom(AccountInfo.class)) {
			return jContext;
		}
		return null;
	}

}
