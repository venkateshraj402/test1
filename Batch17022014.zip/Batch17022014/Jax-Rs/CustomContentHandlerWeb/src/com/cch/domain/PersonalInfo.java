package com.cch.domain;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "personalInfo")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "personalInfo", propOrder = { "ssn", "name" })
public class PersonalInfo {
	@XmlElement
	private String ssn;
	@XmlElement
	private String name;

	public String getSsn() {
		return ssn;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
