package com.bus.resource;

import javax.ws.rs.GET;
import javax.ws.rs.MatrixParam;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/customer")
public class CustomerResource {

	@Path("/firstname/{id:\\d+}")
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String getFirstName(@PathParam("id") int id) {
		return id + "-FirstName";
	}

	@Path("/{id}/name")
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String findName(@PathParam("id") int id) {
		return id + "-Name";
	}

	@Path("{name}")
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String findPersonalInfo(@PathParam("name") String name,
			@MatrixParam("height") int height) {
		return "Name : " + name + " height : " + height;
	}

}
