package com.bus.resource;

import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

@Path("/car/{model}")
public class CarResource {

	/**
	 * Sub resource locator method
	 * 
	 * @return
	 */
	@Path("/{enquiry}")
	public Object service(@PathParam("enquiry") String enquiry) {
		if(enquiry.equals("sales")) {
			return new CarSalesResource();
		} else if(enquiry.equals("service")) {
			return new CarWorkshopResource();
		}
		return null;
	}

}
