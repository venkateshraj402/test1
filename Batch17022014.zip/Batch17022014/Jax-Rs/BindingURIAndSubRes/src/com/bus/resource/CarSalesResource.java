package com.bus.resource;

import javax.ws.rs.GET;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

public class CarSalesResource {
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String getPrice(@PathParam("model") String model) {
		return "Model : " + model + " price : 224223.34f";
	}
}
