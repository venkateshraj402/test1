package com.bus.resource;

import javax.ws.rs.GET;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 * Sub Resource class
 * 
 * @author Sriman
 * 
 */
public class CarWorkshopResource {

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String repair(@PathParam("model") String model) {
		return "Model " + model + " is admitted for repair";
	}
}
