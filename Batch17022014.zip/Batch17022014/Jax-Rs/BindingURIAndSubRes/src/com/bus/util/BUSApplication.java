package com.bus.util;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import com.bus.resource.CarResource;
import com.bus.resource.CustomerResource;

@ApplicationPath("/rest")
public class BUSApplication extends Application {
	private Set<Object> singletons;

	public BUSApplication() {
		singletons = new HashSet<Object>();
		singletons.add(new CustomerResource());
		singletons.add(new CarResource());
	}

	@Override
	public Set<Object> getSingletons() {
		return singletons;
	}

}
