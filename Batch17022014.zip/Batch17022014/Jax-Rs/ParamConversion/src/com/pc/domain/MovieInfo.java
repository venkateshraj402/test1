package com.pc.domain;

public class MovieInfo {
	private int id;

	public MovieInfo(String id) {
		this.id = Integer.parseInt(id);
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

}
