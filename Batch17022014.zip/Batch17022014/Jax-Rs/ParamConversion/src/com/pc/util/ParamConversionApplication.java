package com.pc.util;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import com.pc.resource.NextGenTicketingResource;

@ApplicationPath("/rest")
public class ParamConversionApplication extends Application {
	private Set<Object> singletons;

	public ParamConversionApplication() {
		singletons = new HashSet<Object>();
		singletons.add(new NextGenTicketingResource());
	}

	@Override
	public Set<Object> getSingletons() {
		return singletons;
	}
}
