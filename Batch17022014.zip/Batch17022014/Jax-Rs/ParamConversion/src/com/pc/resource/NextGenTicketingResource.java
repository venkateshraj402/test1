package com.pc.resource;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.pc.domain.MovieInfo;

/**
 * Automatic Type conversion
 */
@Path("/nextGenTicket")
public class NextGenTicketingResource {

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("{id}")
	public String bookTicket(@PathParam("id") MovieInfo movieInfo) {
		return "Ticket booked for movie id : " + movieInfo.getId();
	}

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/cancel")
	public String cancelTickets(@QueryParam("sno") List<Integer> seatNos) {
		boolean isFirst = true;
		StringBuffer buffer = null;
		buffer = new StringBuffer();
		for (Integer sno : seatNos) {
			if (isFirst) {
				buffer.append(sno);
				isFirst = false;
			} else {
				buffer.append(",").append(sno);
			}
		}

		buffer.append(" seats cancelled!");
		return buffer.toString();
	}
}
