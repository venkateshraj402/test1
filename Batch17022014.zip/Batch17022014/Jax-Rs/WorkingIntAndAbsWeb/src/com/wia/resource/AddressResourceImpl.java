package com.wia.resource;

import javax.ws.rs.Path;

@Path("/address")
public class AddressResourceImpl extends AbstractAddressResource {
	@Override
	public String getArea(int zipCode) {
		return "Area : " + zipCode + "-A";
	}
}
