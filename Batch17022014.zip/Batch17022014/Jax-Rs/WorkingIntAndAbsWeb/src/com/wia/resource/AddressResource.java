package com.wia.resource;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Path("/address")
public interface AddressResource {
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	String getArea(@QueryParam("zip") int zipCode);
}
