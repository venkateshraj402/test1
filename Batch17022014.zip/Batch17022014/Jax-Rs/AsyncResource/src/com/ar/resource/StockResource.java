package com.ar.resource;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.container.AsyncResponse;
import javax.ws.rs.container.Suspended;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/stock")
public class StockResource {

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/price/{stocknm}")
	public void getStockPrice(@PathParam("stocknm") String stockName,
			@Suspended AsyncResponse asyncResponse) {
		StockInfoExecutor executor = null;

		executor = new StockInfoExecutor(asyncResponse);
		new Thread(executor).start();
	}

	private final class StockInfoExecutor implements Runnable {
		private AsyncResponse asyncResponse;

		public StockInfoExecutor(AsyncResponse asyncResponse) {
			this.asyncResponse = asyncResponse;
		}

		@Override
		public void run() {
			System.out.println("I am doing big work!...");
			try {
				Thread.sleep(1000L);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			asyncResponse.resume(Response.ok("22424").build());
		}

	}

}
