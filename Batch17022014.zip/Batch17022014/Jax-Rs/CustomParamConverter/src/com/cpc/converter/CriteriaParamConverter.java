package com.cpc.converter;

import javax.ws.rs.ext.ParamConverter;

import com.cpc.domain.Criteria;

public class CriteriaParamConverter implements ParamConverter<Criteria> {

	@Override
	public Criteria fromString(String val) {
		Criteria criteria = null;

		criteria = new Criteria();
		criteria.setFullname(val);
		return criteria;
	}

	@Override
	public String toString(Criteria criteria) {
		return criteria.getFullname();
	}

}
