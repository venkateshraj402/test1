package com.cpc.util;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import com.cpc.provider.CustomParamConverterProvider;
import com.cpc.resource.DirectorySearchResource;

@ApplicationPath("/rest")
public class DirectorySearchApplication extends Application {
	private Set<Object> singletons;
	private Set<Class<?>> classes;

	public DirectorySearchApplication() {
		singletons = new HashSet<Object>();
		singletons.add(new DirectorySearchResource());
		classes = new HashSet<Class<?>>();
		classes.add(CustomParamConverterProvider.class);
	}

	@Override
	public Set<Object> getSingletons() {
		return singletons;
	}

	@Override
	public Set<Class<?>> getClasses() {
		return classes;
	}
	
	

}
