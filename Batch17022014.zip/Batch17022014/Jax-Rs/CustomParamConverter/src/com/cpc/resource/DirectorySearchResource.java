package com.cpc.resource;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.cpc.domain.Criteria;

@Path("/directory")
public class DirectorySearchResource {

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/search/fullname")
	public String search(@QueryParam("fullname") Criteria criteria) {
		return "Telephone no : 2202028222 for Person : "
				+ criteria.getFullname();
	}
}
