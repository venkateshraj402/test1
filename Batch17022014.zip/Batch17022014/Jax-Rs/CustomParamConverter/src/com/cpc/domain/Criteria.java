package com.cpc.domain;

/**
 * This class doesn't qualifies for automatic type conversion because there is
 * no single arg string constructor or valueOf method
 * 
 */
public class Criteria {
	private String fullname;

	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

}
