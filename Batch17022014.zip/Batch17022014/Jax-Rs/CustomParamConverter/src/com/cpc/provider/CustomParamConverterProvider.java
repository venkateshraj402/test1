package com.cpc.provider;

import java.lang.annotation.Annotation;
import java.lang.reflect.Type;

import javax.ws.rs.ext.ParamConverter;
import javax.ws.rs.ext.ParamConverterProvider;
import javax.ws.rs.ext.Provider;

import com.cpc.converter.CriteriaParamConverter;
import com.cpc.domain.Criteria;

@Provider
public class CustomParamConverterProvider implements ParamConverterProvider {

	@Override
	public <T> ParamConverter<T> getConverter(Class<T> classType,
			Type genericType, Annotation[] annotations) {
		System.out.println("ClassType : " + classType.getName());
		System.out
				.println("Generic Type : " + genericType.getClass().getName());
		for (Annotation annon : annotations) {
			System.out.println("annon : " + annon.toString());
		}

		if (classType.isAssignableFrom(Criteria.class)) {
			return (ParamConverter<T>) new CriteriaParamConverter();
		}
		return null;
	}

}
