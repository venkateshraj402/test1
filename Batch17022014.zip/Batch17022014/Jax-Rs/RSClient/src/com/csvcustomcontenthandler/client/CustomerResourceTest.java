package com.csvcustomcontenthandler.client;

import com.csvcustomcontenthandler.client.domain.Customer;

public class CustomerResourceTest {

	public static void main(String[] args) {
		CustomerCSVResource csvResource = null;

		csvResource = new CustomerCSVResource();
		Customer customer = new Customer();
		customer.setName("John");
		customer.setSsn("SS1");
		csvResource.addCustomer(customer);

		customer = csvResource.getCustomer("ssn1");
		System.out.println("Ssn : " + customer.getSsn());
		System.out.println("Name : " + customer.getName());
	}

}
