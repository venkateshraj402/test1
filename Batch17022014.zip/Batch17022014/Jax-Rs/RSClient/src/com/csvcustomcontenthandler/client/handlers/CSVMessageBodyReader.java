package com.csvcustomcontenthandler.client.handlers;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

import javax.ws.rs.Consumes;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.ext.MessageBodyReader;
import javax.ws.rs.ext.Provider;

import com.csvcustomcontenthandler.client.common.CSVType;

@Provider
@Consumes(MediaType.TEXT_PLAIN)
public class CSVMessageBodyReader implements MessageBodyReader<Object> {

	@Override
	public boolean isReadable(Class<?> classType, Type rawType,
			Annotation[] annotations, MediaType mediaType) {
		if (classType.isAnnotationPresent(CSVType.class)) {
			return true;
		}
		return false;
	}

	@Override
	public Object readFrom(Class<Object> classType, Type rawType,
			Annotation[] annotations, MediaType mediaType,
			MultivaluedMap<String, String> httpHeaders, InputStream inputStream)
			throws IOException, WebApplicationException {
		String rawData = null;
		Map<String, String> genericDataMap;
		Object object = null;

		try {
			rawData = extractRawData(inputStream);
			genericDataMap = convert(rawData);
			object = build(genericDataMap, classType);
		} catch (Exception e) {
			throw new WebApplicationException(e);
		}

		return object;
	}

	private String extractRawData(InputStream inputStream) throws IOException {
		int c = -1;
		StringBuffer buffer = null;
		BufferedInputStream bis = null;

		buffer = new StringBuffer();
		bis = new BufferedInputStream(inputStream);

		while ((c = bis.read()) != -1) {
			buffer.append((char) c);
		}
		return buffer.toString();
	}

	private Map<String, String> convert(String data) {
		Map<String, String> genericDataMap = null;
		StringTokenizer tokenizer = null;
		String token = null;
		String parts[] = null;

		// ssn=10,name=john
		// ------ ---------
		// T1 T2
		genericDataMap = new HashMap<String, String>();
		tokenizer = new StringTokenizer(data, ",");
		while (tokenizer.hasMoreTokens()) {
			token = tokenizer.nextToken();
			parts = token.split("=");
			genericDataMap.put(parts[0], parts[1]);
		}

		return genericDataMap;
	}

	public Object build(Map<String, String> dataMap, Class<Object> classType)
			throws InstantiationException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException {
		Object object = null;
		Method method = null;

		object = classType.newInstance();
		for (String attr : dataMap.keySet()) {
			method = getSetterMethod(classType, attr);
			method.invoke(object, dataMap.get(attr));
		}

		return object;
	}

	public Method getSetterMethod(Class<Object> classType, String attribute) {
		String methodName = null;
		Method[] methods = null;

		methodName = "set" + attribute;
		methods = classType.getDeclaredMethods();

		for (Method m : methods) {
			if (m.getName().equalsIgnoreCase(methodName)) {
				return m;
			}
		}
		return null;
	}

}
