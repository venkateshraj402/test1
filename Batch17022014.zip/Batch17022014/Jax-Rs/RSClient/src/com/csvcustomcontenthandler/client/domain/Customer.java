package com.csvcustomcontenthandler.client.domain;

import com.csvcustomcontenthandler.client.common.CSVType;

@CSVType
public class Customer {
	private String ssn;
	private String name;

	public String getSsn() {
		return ssn;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
