package com.csvcustomcontenthandler.client;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.csvcustomcontenthandler.client.domain.Customer;
import com.csvcustomcontenthandler.client.handlers.CSVMessageBodyReader;
import com.csvcustomcontenthandler.client.handlers.CSVMessageBodyWriter;

public class CustomerCSVResource {
	private final static String BASE_URI = "http://localhost:8081/CsvContentHandlerWeb/rest/customer";

	public void addCustomer(Customer customer) {
		ClientBuilder builder = null;
		Client client = null;
		WebTarget target = null;

		try {
			builder = ClientBuilder.newBuilder();
			client = builder.register(CSVMessageBodyReader.class)
					.register(CSVMessageBodyWriter.class).build();

			target = client.target(BASE_URI);
			Response response = target.path("/new").request()
					.accept(MediaType.TEXT_PLAIN)
					.post(Entity.entity(customer, MediaType.TEXT_PLAIN));

			if (response.getStatus() == 200) {
				System.out.println("response : "
						+ response.readEntity(String.class));
			}
		} catch (WebApplicationException e) {
			e.printStackTrace();
		} finally {
			if (client != null) {
				client.close();
			}
		}
	}

	public Customer getCustomer(String ssn) {
		ClientBuilder builder = null;
		Client client = null;
		WebTarget target = null;
		Customer customer = null;

		try {
			builder = ClientBuilder.newBuilder();
			client = builder.register(CSVMessageBodyReader.class)
					.register(CSVMessageBodyWriter.class).build();

			target = client.target(BASE_URI);
			Response response = target.path("/find/{ssn}")
					.resolveTemplate("ssn", ssn).request()
					.accept(MediaType.TEXT_PLAIN).get();
			if (response.getStatus() == 200) {
				customer = response.readEntity(Customer.class);
			}

		} catch (WebApplicationException e) {
			e.printStackTrace();
		}
		return customer;
	}
}
