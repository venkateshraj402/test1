package com.rsurisubres.client;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

public class CustomerResourceClient {
	private final static String BASE_URI = "http://localhost:8081/BindingURIAndSubRes/rest/customer";

	public static void main(String[] args) {
		Client client = null;
		WebTarget target = null;

		client = ClientBuilder.newClient();
		client.property("connection.timeout", "50");

		target = client.target(BASE_URI);

		Response response = target.path("{name}")
				.resolveTemplate("name", "John").matrixParam("height", "6")
				.request().get();
		if (response.getStatus() == 200) {
			response.bufferEntity();
			String personalInfo = response.readEntity(String.class);
			System.out.println("Personal Info : " + personalInfo);
		}
	}
}
