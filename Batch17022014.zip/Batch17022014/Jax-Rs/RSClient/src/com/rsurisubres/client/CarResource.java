package com.rsurisubres.client;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

public class CarResource {
	private static final String BASE_URI = "http://localhost:8081/BindingURIAndSubRes/rest/car/{model}";

	public static void main(String[] args) {
		ClientBuilder builder = null;
		WebTarget target = null;
		Client client = null;

		builder = ClientBuilder.newBuilder();
		client = builder.build();
		target = client.target(BASE_URI);

		// appending sub-resource path
		target = target.path("/{enquiry}");
		target = target.resolveTemplate("model", "Maruthi Swift");
		target = target.resolveTemplate("enquiry", "sales");

		// #1
		// Response response =
		// target.request().accept(MediaType.TEXT_PLAIN).get();

		// #2
		Invocation invocation = target.request().accept(MediaType.TEXT_PLAIN)
				.buildGet();
		Response response = invocation.invoke();

		if (response.getStatus() == 200) {
			String quote = response.readEntity(String.class);
			System.out.println("quote : " + quote);
		}
	}
}
