package com.rsinjection.client;

public class StudentResourceTest {
	public static void main(String[] args) {
		StudentResource resource = new StudentResource();
		//System.out.println(resource.getHeaders());
		System.out.println(resource.register(10, "john"));
	}
}
