package com.rsinjection.client;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.NewCookie;
import javax.ws.rs.core.Response;

public class StudentResource {
	private final static String BASE_URI = "http://localhost:8081/RSInjectionWeb/rest/student";

	private Client client;

	public StudentResource() {
		client = ClientBuilder.newClient();
	}

	public String getStudentDetail(String sid) {
		WebTarget target = null;

		client = ClientBuilder.newClient();
		target = client.target(BASE_URI);

		Response response = target.path("/detail/{sid}")
				.resolveTemplate("sid", sid).request()
				.cookie(new NewCookie("cid", "c1")).get();
		if (response.getStatus() == 200) {
			String details = response.readEntity(String.class);
			return details;
		}

		return null;
	}

	public String getHeaders() {
		WebTarget target = null;

		target = client.target(BASE_URI);
		Response response = target.path("/allHeaders").request()
				.header("myHeader", "header1").get();

		return response.readEntity(String.class);
	}

	public String register(int id, String name) {
		WebTarget target = null;
		Form form = null;

		form = new Form();
		form.param("id", String.valueOf(id));
		form.param("name", name);
		target = client.target(BASE_URI);
		Response response = target.path("/new").request()
				.accept(MediaType.TEXT_PLAIN).post(Entity.form(form));
		if (response.getStatus() == 200) {
			return response.readEntity(String.class);
		}
		return null;
	}

	@Override
	protected void finalize() throws Throwable {
		client.close();
	}

}
