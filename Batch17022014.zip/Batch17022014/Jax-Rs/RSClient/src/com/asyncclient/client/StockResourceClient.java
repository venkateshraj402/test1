package com.asyncclient.client;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

public class StockResourceClient {
	private final static String BASE_URI = "http://localhost:8081/AsyncResource/rest/stock";

	public static void main(String[] args) throws InterruptedException,
			ExecutionException {
		ClientBuilder builder = null;
		Client client = null;
		WebTarget target = null;

		try {

			builder = ClientBuilder.newBuilder();
			client = builder.build();
			target = client.target(BASE_URI);

			Future<Response> future = target.path("/price/{stocknm}")
					.resolveTemplate("stocknm", "ICICIBank").request().async()
					.get();

			// polling
			while (!future.isDone()) {
				Thread.sleep(10);
			}
			Response response = future.get();
			if (response.getStatus() == 200) {
				System.out.println(response.readEntity(String.class));
			}
		} finally {
			client.close();
		}
	}

}
