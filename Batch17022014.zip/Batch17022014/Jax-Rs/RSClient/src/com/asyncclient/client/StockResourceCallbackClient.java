package com.asyncclient.client;

import java.util.concurrent.ExecutionException;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.InvocationCallback;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

public class StockResourceCallbackClient {

	private final static String BASE_URI = "http://localhost:8081/AsyncResource/rest/stock";

	public static void main(String[] args) throws InterruptedException,
			ExecutionException {
		ClientBuilder builder = null;
		Client client = null;
		WebTarget target = null;

		try {

			builder = ClientBuilder.newBuilder();
			client = builder.build();
			target = client.target(BASE_URI);
			target.path("/price/{stocknm}")
					.resolveTemplate("stocknm", "ICICIBANK").request().async()
					.get(new StockResponseCallback());

		} finally {
			//client.close();
		}
	}

	private static final class StockResponseCallback implements
			InvocationCallback<Response> {

		@Override
		public void completed(Response response) {
			System.out.println(response.readEntity(String.class));
		}

		@Override
		public void failed(Throwable throwable) {
			throwable.printStackTrace();
		}

	}
}
