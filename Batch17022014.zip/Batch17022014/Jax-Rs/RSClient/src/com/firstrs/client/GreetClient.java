package com.firstrs.client;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

public class GreetClient {
	public static void main(String[] args) {
		ClientBuilder builder = null;
		Client client = null;
		WebTarget target = null;

		builder = ClientBuilder.newBuilder();
		builder.property("connection.timeout", "60");
		// it creates client with properties we set
		client = builder.build();

		//
		target = client
				.target("http://localhost:8081/FirstresteasyWeb/rest/greet");

		target = target.queryParam("name", "Rama");
		Response response = target.request().accept(MediaType.TEXT_PLAIN).get();
		
		if (response.getStatus() == 200) {
			String message = response.readEntity(String.class);
			System.out.println("Message : " + message);
		}
	}
}
