package com.rw.resource;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.NewCookie;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.Response.Status;

import com.rw.domain.MobileInfo;
import com.rw.domain.StatusInfo;

@Path("/mobile")
public class MobileResource {

	@POST
	@Consumes(MediaType.APPLICATION_XML)
	@Path("/recharge")
	public Response recharge(MobileInfo mobile) {
		NewCookie cookie = null;
		Response response = null;
		ResponseBuilder builder = null;

		cookie = new NewCookie("mobileNo", mobile.getMobileNo());

		builder = Response.noContent();
		builder = builder.header("network-type", "GSM");
		builder = builder.cookie(cookie);

		response = builder.build();
		return response;
	}

	@POST
	@Produces(MediaType.APPLICATION_XML)
	@Path("/activate/{mobileNo}/{message}")
	public Response activateService(@PathParam("mobileNo") String mobileNo,
			@PathParam("message") String serviceMsg) {
		Response response = null;
		StatusInfo si = null;

		si = new StatusInfo();
		si.setMobileNo(mobileNo);
		si.setStatus("Failed");

		response = Response.status(Status.SERVICE_UNAVAILABLE).entity(si)
				.type(MediaType.APPLICATION_XML).build();

		return response;
	}

}
