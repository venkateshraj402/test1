package com.ch.resource;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.LineNumberReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.Reader;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.StreamingOutput;
import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

@Path("/bank")
public class BankResource {

	/**
	 * Example demonstrating InputStream as param
	 * 
	 * @param in
	 * @return
	 */
	@POST
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/in")
	public String transferFunds(InputStream in) {
		BufferedInputStream bis = null;
		StringBuffer buffer = null;
		int c = -1;

		bis = new BufferedInputStream(in);
		buffer = new StringBuffer();
		try {
			while ((c = bis.read()) != -1) {
				buffer.append((char) c);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return buffer.toString();
	}

	/**
	 * Example demonstrating reader as param
	 * 
	 * @param reader
	 * @return
	 */
	@POST
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/reader")
	public String transferFunds(Reader reader) {
		LineNumberReader lineReader = null;
		StringBuffer buffer = null;
		String line = null;

		lineReader = new LineNumberReader(reader);
		buffer = new StringBuffer();
		try {
			while ((line = lineReader.readLine()) != null) {
				buffer.append(line);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return buffer.toString();
	}

	/**
	 * Assuming sample xml as below parse and get payee No request xml -
	 * <payeeInfo><accNo>ac1</accNo><branch>Madhapur</branch></payeeInfo>
	 * response xml - <payeeack><accNo>ac1</accNo><message>You request is under
	 * progress</message></payeeack>
	 * 
	 * @param payeeInfo
	 * @return
	 */
	@POST
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_XML)
	@Path("/addPayee")
	public byte[] addPayee(byte[] payeeInfo) {
		String accNo = null;
		StringBuffer response = null;

		try {
			accNo = getAccountNo(payeeInfo);
			response = new StringBuffer();
			response.append("<payeeack>")
					.append("<accno>")
					.append(accNo)
					.append("</accno>")
					.append("<message>Your request is being processed...</message></payeeack>");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response.toString().getBytes();
	}

	private String getAccountNo(byte[] payeeInfo)
			throws ParserConfigurationException, SAXException, IOException {
		/*
		 * DocumentBuilderFactory factory = null; DocumentBuilder builder =
		 * null; Document doc = null;
		 * 
		 * factory = DocumentBuilderFactory.newInstance(); builder =
		 * factory.newDocumentBuilder();
		 */

		String s = new String(payeeInfo);
		String accNo = s.substring(s.indexOf("<accno>") + 7,
				s.indexOf("</accno>"));
		/*
		 * ByteArrayInputStream bis = new ByteArrayInputStream(payeeInfo); doc =
		 * builder.parse(bis);
		 * 
		 * NodeList accNoNodeList = doc.getElementsByTagName("accNo"); return
		 * accNoNodeList.item(0).getTextContent();
		 */
		return accNo;
	}

	@Path("/desposit")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_PLAIN)
	@POST
	public String deposit(MultivaluedMap<String, String> formData) {
		return "Amount is deposited into acc : " + formData.getFirst("accno");
	}

	/**
	 * Example on StreamingOuput as response
	 * 
	 * @param accNo
	 * @return
	 */
	@GET
	@Produces(MediaType.APPLICATION_XML)
	@Path("/balance/{accno}")
	public StreamingOutput getAccountBalance(
			final @PathParam("accno") String accNo) {
		return new StreamingOutput() {
			@Override
			public void write(OutputStream outputStream) throws IOException,
					WebApplicationException {
				PrintWriter out = new PrintWriter(outputStream);
				out.print("<bank>");
				out.print("<accno>" + accNo + "</accNo>");
				out.print("<bal>0.0</bal>");
				out.print("</bank>");
				out.close();
			}
		};
	}

	@POST
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/applyLoan")
	public String applyLoan(File form16) throws IOException {
		int c = -1;
		FileReader reader = null;

		try {
			reader = new FileReader(form16);
			while ((c = reader.read()) != -1) {
				System.out.print((char) c);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			reader.close();
		}

		return "Your form16 has been uploaded successfully!";
	}

}
