package com.ch.util;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import com.ch.resource.BankResource;

@ApplicationPath("/rest")
public class ContentHandlerApplication extends Application {
	private Set<Object> singletons;

	public ContentHandlerApplication() {
		singletons = new HashSet<Object>();
		singletons.add(new BankResource());
	}

	@Override
	public Set<Object> getSingletons() {
		return singletons;
	}

}
