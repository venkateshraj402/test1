package com.sw.resource;

import javax.annotation.security.RolesAllowed;
import javax.ws.rs.ForbiddenException;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.SecurityContext;

@Path("/bank")
/* @RolesAllowed({"admin"}) */
public class BankResource {

	@Context
	private SecurityContext sContext;

	@Path("/bal/{accno}")
	@Produces(MediaType.TEXT_PLAIN)
	@GET
	public float getBalance(@PathParam("accno") String accountNo) {
		if (!sContext.isUserInRole("admin")) {
			throw new ForbiddenException("UnAuthorized access");
		}
		System.out.println("getBalance(" + accountNo + ")");
		return 3523.34f;
	}
}
