package com.sw.util;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import com.sw.resource.BankResource;

@ApplicationPath("/rest")
public class SecurityApplication extends Application {
	private Set<Object> singletons;

	public SecurityApplication() {
		singletons = new HashSet<Object>();
		singletons.add(new BankResource());
	}

	@Override
	public Set<Object> getSingletons() {
		return singletons;
	}

}
