package com.ua.resource;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Path("/enquiry")
public class RailEnquiryResource {

	public RailEnquiryResource() {
		System.out.println("RailEnquiryResource created...");
	}

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String getPnrStatus(@QueryParam("pnr") String pnr) {
		return "Pnr : " + pnr + " status : WL/1";
	}
}
