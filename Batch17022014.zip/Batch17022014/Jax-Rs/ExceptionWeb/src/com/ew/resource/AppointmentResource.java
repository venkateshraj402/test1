package com.ew.resource;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.ServiceUnavailableException;
import javax.ws.rs.core.MediaType;

import com.ew.delegate.AppointmentDelegate;
import com.ew.util.GenericException;

@Path("/appointment")
public class AppointmentResource {

	@POST
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/add/{work}")
	public String addAppointment(@PathParam("work") String work) {
		AppointmentDelegate delegate = null;

		delegate = new AppointmentDelegate();
		delegate.bookAppointment(work);

		return "Appointment booked";
	}

}
