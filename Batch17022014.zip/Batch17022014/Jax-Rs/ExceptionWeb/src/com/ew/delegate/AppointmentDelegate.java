package com.ew.delegate;

import com.ew.util.GenericException;

public class AppointmentDelegate {
	public void bookAppointment(String work) {
		throw new GenericException("unable to book appointment");
	}
}
