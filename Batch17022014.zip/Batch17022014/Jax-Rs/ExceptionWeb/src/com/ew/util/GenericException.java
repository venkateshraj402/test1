package com.ew.util;

public class GenericException extends RuntimeException {
	private String reason;

	public GenericException() {
		// no-op
	}

	public GenericException(String reason) {
		this.reason = reason;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

}
