package com.ew.util;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

@Provider
public class GenericExceptionMapper implements
		ExceptionMapper<GenericException> {

	@Override
	public Response toResponse(GenericException ge) {
		return Response.status(Status.SERVICE_UNAVAILABLE)
				.entity(ge.getReason()).type(MediaType.TEXT_PLAIN).build();
	}

}
