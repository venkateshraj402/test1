package com.cch.handler;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Type;

import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.ext.MessageBodyWriter;
import javax.ws.rs.ext.Provider;

import com.cch.common.CSVType;

@Provider
@Produces(MediaType.TEXT_PLAIN)
public class CSVMessageBodyWriter implements MessageBodyWriter<Object> {

	@Override
	public long getSize(Object object, Class<?> classType, Type rawType,
			Annotation[] annotations, MediaType mediaType) {
		return 0;
	}

	@Override
	public boolean isWriteable(Class<?> classType, Type rawType,
			Annotation[] annotations, MediaType mediaType) {
		if (classType.isAnnotationPresent(CSVType.class)) {
			return true;
		}
		return false;
	}

	@Override
	public void writeTo(Object object, Class<?> classType, Type rawType,
			Annotation[] annotations, MediaType mediaType,
			MultivaluedMap<String, Object> httpHeaders,
			OutputStream outputStream) throws IOException,
			WebApplicationException {
		PrintWriter out = null;
		String content = null;
				
		try {
			out = new PrintWriter(outputStream);
			content = buildResponse(classType, object);
			out.print(content);
		}catch (Exception e) {
			e.printStackTrace();
			throw new WebApplicationException(e);
		}finally {
			out.close();
		}
	}

	private String buildResponse(Class<?> classType, Object object)
			throws IllegalArgumentException, IllegalAccessException {
		StringBuffer buffer = null;
		Method method = null;
		boolean isFirst = true;
		
		buffer = new StringBuffer();

		for (Field field : classType.getDeclaredFields()) {
			field.setAccessible(true);
			if(isFirst) {
			buffer.append(field.getName()).append("=")
					.append(field.get(object));
			} else {
				buffer.append(",").append(field.getName()).append("=")
				.append(field.get(object));
			}
			isFirst = false;			
		}
		return buffer.toString();
	}
}
