package com.cch.resource;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.cch.domain.Customer;

@Path("/customer")
public class CustomerResource {

	@POST
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/new")
	public String addCustomer(Customer customer) {
		return "Customer : " + customer.getSsn() + " addedd successfully";
	}

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/find/{ssn}")
	public Customer findCustomer(@PathParam("ssn") String ssn) {
		Customer c = new Customer();
		c.setSsn(ssn);
		c.setName("John");

		return c;
	}

}
