package com.iw.domain;

import javax.ws.rs.FormParam;
import javax.ws.rs.PathParam;

public class SearchCriteria {
	@FormParam("id")
	private int id;
	@FormParam("name")
	private String name;
	@PathParam("collegeId")
	private String collegeId;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCollegeId() {
		return collegeId;
	}

	public void setCollegeId(String collegeId) {
		this.collegeId = collegeId;
	}

}
