package com.iw.resource;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;

import javax.ws.rs.GET;
import javax.ws.rs.MatrixParam;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.PathSegment;
import javax.ws.rs.core.StreamingOutput;

/**
 * Working with Path Segment
 * 
 * @author Sriman
 */
@Path("/car")
public class CarResource {

	@GET
	@Produces(MediaType.APPLICATION_XML)
	@Path("/{make}")
	/**
	 * Dynamically retrieve all Matrix Parameters for a PathSegment
	 * @param make
	 * @param model
	 * @return
	 */
	public StreamingOutput getCar(@PathParam("make") PathSegment makePS) {
		MultivaluedMap<String, String> matrixParams = null;
		StringBuffer buffer = null;

		buffer = new StringBuffer();
		buffer.append("<car>");
		matrixParams = makePS.getMatrixParameters();
		for (String key : matrixParams.keySet()) {
			buffer.append("<" + key + ">").append(matrixParams.getFirst(key))
					.append("</" + key + ">");

		}
		buffer.append("</car>");
		return new CarXmlStreamingOutput(buffer.toString());
	}

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/price/{make}/{model}")
	/**
	 * [Problem]
	 * Limitation with @MatrixParameter (resolving it using pathSegment)
	 * e.g.. uri /rest/car/price/maruthi;color=red/swift;color=white
	 * @param make
	 * @param model
	 * @param color
	 * @return
	 */
	/*
	 * public String getCarPrice(@PathParam("make") String make,
	 * 
	 * @PathParam("model") String model, @MatrixParam("color") String color) {
	 * return "Price : 242422 for color : " + color; }
	 */
	public String getCarPrice(@PathParam("make") PathSegment makePS,
			@PathParam("model") PathSegment modelPS) {
		return "Price : 242422 for color : make Color"
				+ makePS.getMatrixParameters().getFirst("color")
				+ " model Color : "
				+ modelPS.getMatrixParameters().getFirst("color");
	}

	private final class CarXmlStreamingOutput implements StreamingOutput {
		private String xml;

		public CarXmlStreamingOutput(String xml) {
			this.xml = xml;
		}

		@Override
		public void write(OutputStream outputStream) throws IOException,
				WebApplicationException {
			PrintWriter pw = new PrintWriter(outputStream);
			pw.print(xml);
			pw.close();
		}

	}

}
