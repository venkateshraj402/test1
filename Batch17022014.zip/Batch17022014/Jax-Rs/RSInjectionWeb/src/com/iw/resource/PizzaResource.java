package com.iw.resource;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.PathSegment;

@Path("/pizza/{id}")
public class PizzaResource {

	@Path("/order/{id}-{quantity}")
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String placeOrder(@PathParam("id") int storeId,
			@PathParam("id") int pizzaId, @PathParam("quantity") int quantity) {
		return "Store Id : " + storeId + " pizzaId : " + pizzaId
				+ " quantity : " + quantity + " order is placed!";
	}

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/{pizzaId}")
	public float getPrice(@PathParam("id") int storeId,
			@PathParam("pizzaId") PathSegment pizzaIdPathSegment) {
		return storeId + Integer.parseInt(pizzaIdPathSegment.getPath());
	}

}
