package com.iw.resource;

import javax.ws.rs.BeanParam;
import javax.ws.rs.CookieParam;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.UriInfo;

import com.iw.domain.SearchCriteria;

@Path("/student")
public class StudentResource {

	@Path("{examNo}")
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String getGrade(@Context UriInfo uri) {
		StringBuffer buffer = null;
		MultivaluedMap<String, String> queryParams = null;
		MultivaluedMap<String, String> pathParams = null;

		buffer = new StringBuffer();
		queryParams = uri.getQueryParameters();
		for (String paramName : queryParams.keySet()) {
			buffer.append("name : ").append(paramName).append(" value : ")
					.append(queryParams.getFirst(paramName));
		}

		System.out.println("###########Path Parameters ########");
		pathParams = uri.getPathParameters();
		for (String paramName : pathParams.keySet()) {
			System.out.println("Name : " + paramName + " value : "
					+ pathParams.getFirst(paramName));
		}

		return buffer.toString();
	}

	@Path("/detail/{sid}")
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String getStudentDetails(@CookieParam("cid") String collegeId,
			@PathParam("sid") String studentId) {
		return "Student id : " + studentId + " collegeId : " + collegeId;
	}

	@GET
	@Path("/userAgent")
	@Produces(MediaType.TEXT_PLAIN)
	public String getUserAgent(@HeaderParam("User-Agent") String userAgent) {
		return "User Agent : " + userAgent;
	}

	@GET
	@Path("/allHeaders")
	@Produces(MediaType.TEXT_PLAIN)
	public String getAllHeaders(@Context HttpHeaders headers) {
		StringBuffer buffer = null;
		MultivaluedMap<String, String> reqHeaders = null;

		buffer = new StringBuffer();

		reqHeaders = headers.getRequestHeaders();
		for (String paramName : reqHeaders.keySet()) {
			buffer.append("Name : ").append(paramName).append(" value : ")
					.append(reqHeaders.getFirst(paramName));
		}
		return buffer.toString();
	}

	@POST
	@Path("/new")
	@Produces(MediaType.TEXT_PLAIN)
	public String register(@FormParam("id") int id,
			@FormParam("name") String name) {
		return "Student id : " + id + " name : " + name
				+ " registered successfully";
	}

	@POST
	@Path("{collegeId}/search")
	@Produces(MediaType.TEXT_PLAIN)
	public String search(@BeanParam SearchCriteria criteria) {
		return "Id : " + criteria.getId() + " collegeId : "
				+ criteria.getCollegeId() + " name : " + criteria.getName();
	}

}
