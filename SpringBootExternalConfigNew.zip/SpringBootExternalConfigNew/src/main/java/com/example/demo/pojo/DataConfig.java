package com.example.demo.pojo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
public class DataConfig {
	
	@Bean(name="config")
	@Profile(value="development")
	Config development() {
		return new Config("http://development.com", 8080);
	}
	
	@Bean(name="config")
	@Profile(value="production")
	Config production() {
		return new Config("http://production.com", 9080);
	}

}
