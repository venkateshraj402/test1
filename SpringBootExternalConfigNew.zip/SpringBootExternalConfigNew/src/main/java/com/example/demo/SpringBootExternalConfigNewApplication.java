package com.example.demo;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;

import com.example.demo.pojo.Config;
import com.example.demo.pojo.MyAppConfig;

@SpringBootApplication
@EnableConfigurationProperties
public class SpringBootExternalConfigNewApplication {

	public static void main(String[] args) {
		ApplicationContext applicationContext = SpringApplication.run(SpringBootExternalConfigNewApplication.class, args);
		Config appConfig = applicationContext.getBean(Config.class);
		System.out.println(appConfig.toString());
	}
	
	/*@Bean
	public Config getConfig() {
		return new Config("test", 9080);
	}*/
}
