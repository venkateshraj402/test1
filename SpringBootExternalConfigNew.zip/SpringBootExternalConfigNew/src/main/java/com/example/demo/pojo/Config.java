package com.example.demo.pojo;

public class Config {
	
	private String url;
	
	private int port;

	/**
	 * @param url
	 * @param port
	 */
	public Config(String url, int port) {
		super();
		this.url = url;
		this.port = port;
	}

	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * @param url the url to set
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * @return the port
	 */
	public int getPort() {
		return port;
	}

	/**
	 * @param port the port to set
	 */
	public void setPort(int port) {
		this.port = port;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Config [url=" + url + ", port=" + port + "]";
	}

}
